import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    private ContactService service;

    @BeforeEach
    public void setUp() {
        service = new ContactService();
    }

    @Test
    public void testAddContact() {
        Contact contact = new Contact("ID1", "John", "Doe", "1234567890", "123 St");
        service.addContact(contact);
        assertNotNull(service);
    }

    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("ID1", "John", "Doe", "1234567890", "123 St");
        service.addContact(contact);
        service.deleteContact("ID1");
        assertNull(service);
    }

    @Test
    public void testUpdateContact() {
        Contact contact = new Contact("ID1", "John", "Doe", "1234567890", "123 St");
        service.addContact(contact);
        service.updateContact("ID1", "Jane", "Doe", "0987654321", "321 St");
        assertNotNull(service);
    }
}
