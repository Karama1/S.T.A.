import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

	@Test
	public void testValidContactCreation() {
	    try {
	        new Contact("ID1", "John", "Doe", "1234567890", "123 St");
	    } catch (Exception e) {
	        fail("Should not have thrown any exception");
	    }
	}

    @Test
    public void testInvalidContactId() {
        assertThrows(IllegalArgumentException.class, () -> new Contact(null, "John", "Doe", "1234567890", "123 St"));
    }

    @Test
    public void testInvalidFirstName() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("ID1", null, "Doe", "1234567890", "123 St"));
    }

    @Test
    public void testInvalidLastName() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("ID1", "John", null, "1234567890", "123 St"));
    }

    @Test
    public void testInvalidPhone() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("ID1", "John", "Doe", null, "123 St"));
    }

    @Test
    public void testInvalidAddress() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("ID1", "John", "Doe", "1234567890", null));
    }
}
