import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private final Map<String, Contact> contacts;

    public ContactService() {
        this.contacts = new HashMap<>();
    }

    // Add a contact
    public void addContact(Contact contact) {
        if (!contacts.containsKey(contact.getContactId())) {
            contacts.put(contact.getContactId(), contact);
        }
    }

    // Delete a contact by ID
    public void deleteContact(String contactId) {
        contacts.remove(contactId);
    }

    // Update contact fields by ID
    public void updateContact(String contactId, String firstName, String lastName, String phone, String address) {
        if (contacts.containsKey(contactId)) {
            Contact contact = contacts.get(contactId);
            contact.setFirstName(firstName);
            contact.setLastName(lastName);
            contact.setPhone(phone);
            contact.setAddress(address);
        }
    }
}
